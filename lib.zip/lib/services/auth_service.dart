import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';

import '../core/database/app_database.dart';
import '../models/user.dart';

class AuthService {
  final AppDatabase _database = AppDatabase.instance;

  Future<User?> login(String username, String pin) async {
    final db = await _database.database;
    final rows = await db.query(
      'users',
      where: 'username = ? AND is_active = 1',
      whereArgs: [username],
      limit: 1,
    );

    if (rows.isEmpty) return null;

    final user = User.fromMap(rows.first);
    final inputHash = sha256.convert(utf8.encode(pin)).toString();
    if (user.pinHash == inputHash) {
      return user;
    }

    return null;
  }

  Future<bool> changePin(int userId, String newPin) async {
    final db = await _database.database;
    final hash = sha256.convert(utf8.encode(newPin)).toString();

    final updated = await db.update(
      'users',
      {'pin_hash': hash},
      where: 'id = ?',
      whereArgs: [userId],
    );

    return updated == 1;
  }

  Future<String> generateHash(String value) async {
    final digest = sha256.convert(utf8.encode(value));
    return digest.toString();
  }

  Future<void> logActivity(
    Database db,
    String entityType,
    String action,
    String message,
  ) async {
    await db.insert('activity_logs', {
      'entity_type': entityType,
      'action': action,
      'message': message,
      'created_at': DateTime.now().toIso8601String(),
    });
  }
}
