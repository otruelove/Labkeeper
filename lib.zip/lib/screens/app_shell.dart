import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/constants.dart';
import '../models/equipment.dart';
import '../models/user.dart';
import '../repositories/equipment_repository.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({required this.user, super.key});

  final User user;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  late final List<Widget> _pages = [
    _DashboardPage(onOpenEquipment: () => _selectPage(1)),
    EquipmentListScreen(onChanged: _refresh),
    TransactionsScreen(onChanged: _refresh),
    const ReportsScreen(),
  ];

  void _selectPage(int index) {
    setState(() => _selectedIndex = index);
  }

  void _refresh() {
    if (!mounted) return;
    setState(() {
      _pages[0] = _DashboardPage(onOpenEquipment: () => _selectPage(1));
      _pages[1] = EquipmentListScreen(onChanged: _refresh);
      _pages[2] = TransactionsScreen(onChanged: _refresh);
      _pages[3] = const ReportsScreen();
    });
  }

  Future<void> _openMore(String value) async {
    Widget? screen;
    switch (value) {
      case 'maintenance':
        screen = MaintenanceScreen(onChanged: _refresh);
      case 'damage':
        screen = DamageReportsScreen(onChanged: _refresh);
      case 'settings':
        screen = SettingsScreen(user: widget.user);
    }
    if (screen != null) {
      await Navigator.of(
        context,
      ).push(MaterialPageRoute(builder: (_) => screen!));
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          ['Dashboard', 'Equipment', 'Transactions', 'Reports'][_selectedIndex],
        ),
        actions: [
          PopupMenuButton<String>(
            tooltip: 'More options',
            onSelected: _openMore,
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'maintenance',
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.build_outlined),
                  title: Text('Maintenance'),
                ),
              ),
              PopupMenuItem(
                value: 'damage',
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.report_problem_outlined),
                  title: Text('Damage reports'),
                ),
              ),
              PopupMenuItem(
                value: 'settings',
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.settings_outlined),
                  title: Text('Settings'),
                ),
              ),
            ],
          ),
        ],
      ),
      body: IndexedStack(index: _selectedIndex, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _selectPage,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            selectedIcon: Icon(Icons.inventory_2),
            label: 'Equipment',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Transactions',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart),
            label: 'Reports',
          ),
        ],
      ),
    );
  }
}

class _DashboardPage extends StatefulWidget {
  const _DashboardPage({required this.onOpenEquipment});

  final VoidCallback onOpenEquipment;

  @override
  State<_DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<_DashboardPage> {
  final _repository = EquipmentRepository();
  Map<String, int> _summary = {};
  List<Equipment> _equipment = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final summary = await _repository.getDashboardSummary();
      final equipment = await _repository.getAll();
      if (!mounted) return;
      setState(() {
        _summary = summary;
        _equipment = equipment;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return _ErrorView(message: _error!, onRetry: _load);
    }
    final stats = [
      _StatCard(
        title: 'Total units',
        value: '${_summary['total_units'] ?? 0}',
        color: Colors.teal,
      ),
      _StatCard(
        title: 'Available',
        value: '${_summary['available_units'] ?? 0}',
        color: Colors.green,
      ),
      _StatCard(
        title: 'Issued',
        value: '${_summary['issued_units'] ?? 0}',
        color: Colors.blue,
      ),
      _StatCard(
        title: 'Damaged',
        value: '${_summary['damaged_units'] ?? 0}',
        color: Colors.orange,
      ),
      _StatCard(
        title: 'Maintenance',
        value: '${_summary['maintenance_units'] ?? 0}',
        color: Colors.deepOrange,
      ),
    ];

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Laboratory Overview',
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 16),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 1.55,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: stats,
          ),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: [
                ListTile(
                  title: const Text(
                    'Recent equipment',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  trailing: TextButton(
                    onPressed: widget.onOpenEquipment,
                    child: const Text('View all'),
                  ),
                ),
                if (_equipment.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text(
                      'No equipment registered yet. Add an item to get started.',
                    ),
                  )
                else
                  ..._equipment
                      .take(5)
                      .map(
                        (item) => ListTile(
                          leading: const Icon(Icons.science_outlined),
                          title: Text(item.name),
                          subtitle: Text(
                            '${item.equipmentCode} • ${item.room}',
                          ),
                          trailing: Text(
                            '${item.availableQuantity}/${item.totalQuantity}',
                          ),
                        ),
                      ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                const ListTile(
                  leading: Icon(Icons.bolt_outlined),
                  title: Text('Quick actions'),
                ),
                ListTile(
                  leading: const Icon(Icons.add_box_outlined),
                  title: const Text('Add equipment'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: widget.onOpenEquipment,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class EquipmentListScreen extends StatefulWidget {
  const EquipmentListScreen({required this.onChanged, super.key});

  final VoidCallback onChanged;

  @override
  State<EquipmentListScreen> createState() => _EquipmentListScreenState();
}

class _EquipmentListScreenState extends State<EquipmentListScreen> {
  final _repository = EquipmentRepository();
  final _searchController = TextEditingController();
  List<Equipment> _equipment = [];
  String _condition = 'All conditions';
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _repository.getAll();
      if (!mounted) return;
      setState(() {
        _equipment = rows;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _edit({Equipment? equipment}) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => EquipmentForm(equipment: equipment),
    );
    if (saved == true) {
      await _load();
      widget.onChanged();
    }
  }

  Future<void> _archive(Equipment item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Archive equipment?'),
        content: Text('Archive ${item.name}? Existing history will be kept.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Archive'),
          ),
        ],
      ),
    );
    if (confirmed != true || item.id == null) return;
    try {
      await _repository.archive(item.id!);
      await _load();
      widget.onChanged();
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final search = _searchController.text.trim().toLowerCase();
    final filtered = _equipment.where((item) {
      final matchesText =
          search.isEmpty ||
          item.name.toLowerCase().contains(search) ||
          item.equipmentCode.toLowerCase().contains(search) ||
          item.category.toLowerCase().contains(search) ||
          item.room.toLowerCase().contains(search);
      final matchesCondition =
          _condition == 'All conditions' || item.conditionStatus == _condition;
      return matchesText && matchesCondition;
    }).toList();

    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return _ErrorView(message: _error!, onRetry: _load);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: const InputDecoration(
                    hintText: 'Search equipment',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              DropdownButton<String>(
                value: _condition,
                items: const ['All conditions', 'Good', 'Fair', 'Damaged']
                    .map(
                      (value) =>
                          DropdownMenuItem(value: value, child: Text(value)),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) setState(() => _condition = value);
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _load,
            child: filtered.isEmpty
                ? ListView(
                    children: [
                      const SizedBox(height: 100),
                      Icon(
                        Icons.inventory_2_outlined,
                        size: 56,
                        color: Colors.grey.shade500,
                      ),
                      const SizedBox(height: 12),
                      Center(
                        child: Text(
                          search.isEmpty
                              ? 'No equipment yet.'
                              : 'No matching equipment.',
                        ),
                      ),
                    ],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final item = filtered[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          onTap: () => _edit(equipment: item),
                          leading: CircleAvatar(
                            backgroundColor: Theme.of(
                              context,
                            ).colorScheme.primaryContainer,
                            child: const Icon(Icons.science),
                          ),
                          title: Text(item.name),
                          subtitle: Text(
                            '${item.equipmentCode} • ${item.category}\n${item.room} • Qty ${item.availableQuantity}/${item.totalQuantity}',
                          ),
                          isThreeLine: true,
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') _edit(equipment: item);
                              if (value == 'archive') _archive(item);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('Edit')),
                              PopupMenuItem(
                                value: 'archive',
                                child: Text('Archive'),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => _edit(),
              icon: const Icon(Icons.add),
              label: const Text('Add equipment'),
            ),
          ),
        ),
      ],
    );
  }
}

class EquipmentForm extends StatefulWidget {
  const EquipmentForm({this.equipment, super.key});

  final Equipment? equipment;

  @override
  State<EquipmentForm> createState() => _EquipmentFormState();
}

class _EquipmentFormState extends State<EquipmentForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _code;
  late final TextEditingController _name;
  late final TextEditingController _category;
  late final TextEditingController _room;
  late final TextEditingController _quantity;
  late final TextEditingController _brand;
  late final TextEditingController _model;
  late final TextEditingController _serial;
  late final TextEditingController _price;
  late final TextEditingController _notes;
  String _condition = 'Good';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final item = widget.equipment;
    _code = TextEditingController(text: item?.equipmentCode ?? '');
    _name = TextEditingController(text: item?.name ?? '');
    _category = TextEditingController(text: item?.category ?? '');
    _room = TextEditingController(text: item?.room ?? '');
    _quantity = TextEditingController(
      text: item?.totalQuantity.toString() ?? '1',
    );
    _brand = TextEditingController(text: item?.brand ?? '');
    _model = TextEditingController(text: item?.model ?? '');
    _serial = TextEditingController(text: item?.serialNumber ?? '');
    _price = TextEditingController(text: item?.unitPrice?.toString() ?? '');
    _notes = TextEditingController(text: item?.notes ?? '');
    _condition = item?.conditionStatus ?? 'Good';
  }

  @override
  void dispose() {
    for (final controller in [
      _code,
      _name,
      _category,
      _room,
      _quantity,
      _brand,
      _model,
      _serial,
      _price,
      _notes,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final item = Equipment(
      id: widget.equipment?.id,
      equipmentCode: _code.text.trim(),
      name: _name.text.trim(),
      category: _category.text.trim(),
      brand: _blankToNull(_brand.text),
      model: _blankToNull(_model.text),
      serialNumber: _blankToNull(_serial.text),
      totalQuantity: int.parse(_quantity.text),
      availableQuantity:
          widget.equipment?.availableQuantity ?? int.parse(_quantity.text),
      room: _room.text.trim(),
      unitPrice: _price.text.trim().isEmpty ? null : double.parse(_price.text),
      conditionStatus: _condition,
      status: widget.equipment?.status ?? 'Available',
      calibrationRequired: widget.equipment?.calibrationRequired ?? false,
      notes: _blankToNull(_notes.text),
      createdAt: widget.equipment?.createdAt,
    );
    try {
      final repository = EquipmentRepository();
      if (widget.equipment == null) {
        await repository.insert(item);
      } else {
        await repository.update(item);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        _showMessage(context, error.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: Form(
        key: _formKey,
        child: ListView(
          shrinkWrap: true,
          children: [
            Text(
              widget.equipment == null ? 'Add equipment' : 'Edit equipment',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            _textField(_code, 'Equipment code', required: true),
            _textField(_name, 'Name', required: true),
            _textField(_category, 'Category', required: true),
            _textField(_room, 'Room', required: true),
            _textField(
              _quantity,
              'Total quantity',
              required: true,
              numeric: true,
              integer: true,
            ),
            _textField(_brand, 'Brand'),
            _textField(_model, 'Model'),
            _textField(_serial, 'Serial number'),
            _textField(_price, 'Unit price', numeric: true),
            DropdownButtonFormField<String>(
              value: _condition,
              decoration: const InputDecoration(labelText: 'Condition'),
              items: const ['Good', 'Fair', 'Damaged']
                  .map(
                    (value) =>
                        DropdownMenuItem(value: value, child: Text(value)),
                  )
                  .toList(),
              onChanged: (value) =>
                  setState(() => _condition = value ?? 'Good'),
            ),
            _textField(_notes, 'Notes', maxLines: 2),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: _saving ? null : _save,
              child: Text(_saving ? 'Saving...' : 'Save equipment'),
            ),
          ],
        ),
      ),
    );
  }
}

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({required this.onChanged, super.key});

  final VoidCallback onChanged;

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final _repository = EquipmentRepository();
  List<Map<String, Object?>> _records = [];
  bool _activeOnly = true;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await _repository.getTransactions(activeOnly: _activeOnly);
      if (!mounted) return;
      setState(() {
        _records = result;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _issue() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const IssueForm(),
    );
    if (result == true) {
      await _load();
      widget.onChanged();
    }
  }

  Future<void> _return(Map<String, Object?> row) async {
    final outstanding = row['quantity_outstanding'] as int;
    final quantityController = TextEditingController(text: '1');
    final notesController = TextEditingController();
    var condition = 'Good';
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Record return'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Outstanding: $outstanding unit(s)'),
                TextField(
                  controller: quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Quantity returned',
                  ),
                ),
                DropdownButtonFormField<String>(
                  value: condition,
                  decoration: const InputDecoration(
                    labelText: 'Returned condition',
                  ),
                  items: const ['Good', 'Fair', 'Damaged']
                      .map(
                        (value) =>
                            DropdownMenuItem(value: value, child: Text(value)),
                      )
                      .toList(),
                  onChanged: (value) =>
                      setDialogState(() => condition = value ?? 'Good'),
                ),
                TextField(
                  controller: notesController,
                  decoration: const InputDecoration(
                    labelText: 'Notes (optional)',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Save return'),
            ),
          ],
        ),
      ),
    );
    if (result != true) {
      quantityController.dispose();
      notesController.dispose();
      return;
    }
    try {
      final quantity = int.parse(quantityController.text.trim());
      await _repository.returnEquipment(
        issueId: row['id'] as int,
        quantity: quantity,
        condition: condition,
        notes: notesController.text,
      );
      await _load();
      widget.onChanged();
      if (mounted) _showMessage(context, 'Return saved.');
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    } finally {
      quantityController.dispose();
      notesController.dispose();
    }
  }

  Future<void> _showReturnHistory(Map<String, Object?> row) async {
    try {
      final history = await _repository.getReturnHistory(row['id'] as int);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        useSafeArea: true,
        builder: (context) => Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            shrinkWrap: true,
            children: [
              Text(
                'Return history • ${row['transaction_code']}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 10),
              if (history.isEmpty)
                const Text('No units have been returned yet.')
              else
                ...history.map(
                  (entry) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.assignment_return_outlined),
                    title: Text(
                      '${entry['quantity_returned']} unit(s) • ${entry['condition_on_return']}',
                    ),
                    subtitle: Text(
                      '${_date(entry['return_date'] as String?)}'
                      '${(entry['notes'] as String? ?? '').isEmpty ? '' : '\n${entry['notes']}'}',
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Row(
            children: [
              Expanded(
                child: SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: true, label: Text('Active')),
                    ButtonSegment(value: false, label: Text('All history')),
                  ],
                  selected: {_activeOnly},
                  onSelectionChanged: (value) {
                    setState(() => _activeOnly = value.first);
                    _load();
                  },
                ),
              ),
              const SizedBox(width: 10),
              IconButton.filled(
                tooltip: 'Issue equipment',
                onPressed: _issue,
                icon: const Icon(Icons.add),
              ),
            ],
          ),
        ),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
              ? _ErrorView(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: _records.isEmpty
                      ? ListView(
                          children: const [
                            SizedBox(height: 100),
                            Icon(Icons.receipt_long_outlined, size: 52),
                            SizedBox(height: 12),
                            Center(child: Text('No transactions found.')),
                          ],
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _records.length,
                          itemBuilder: (context, index) {
                            final row = _records[index];
                            final outstanding =
                                row['quantity_outstanding'] as int;
                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    InkWell(
                                      onTap: () => _showReturnHistory(row),
                                      child: Text(
                                        '${row['equipment_name']}',
                                        style: Theme.of(
                                          context,
                                        ).textTheme.titleMedium,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${row['transaction_code']} • ${row['borrower_name']}',
                                    ),
                                    Text(
                                      'Borrower ID: ${row['borrower_id']} • ${row['borrower_type']}',
                                    ),
                                    Text(
                                      'Issued ${row['quantity_issued']} • Returned ${row['quantity_returned']} • Due ${_date(row['expected_return_date'] as String?)}',
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        Chip(label: Text('${row['status']}')),
                                        const Spacer(),
                                        if (outstanding > 0)
                                          FilledButton.tonal(
                                            onPressed: () => _return(row),
                                            child: const Text('Return'),
                                          ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
        ),
      ],
    );
  }
}

class IssueForm extends StatefulWidget {
  const IssueForm({super.key});

  @override
  State<IssueForm> createState() => _IssueFormState();
}

class _IssueFormState extends State<IssueForm> {
  final _formKey = GlobalKey<FormState>();
  final _repository = EquipmentRepository();
  final _name = TextEditingController();
  final _borrowerId = TextEditingController();
  final _purpose = TextEditingController();
  final _quantity = TextEditingController(text: '1');
  List<Equipment> _equipment = [];
  Equipment? _selected;
  DateTime _dueDate = DateTime.now().add(const Duration(days: 7));
  String _borrowerType = 'Student';
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadEquipment();
  }

  Future<void> _loadEquipment() async {
    try {
      final items = await _repository.getAll();
      if (!mounted) return;
      setState(() {
        _equipment = items
            .where(
              (item) =>
                  item.availableQuantity > 0 &&
                  item.conditionStatus != 'Damaged' &&
                  item.status != 'Under Maintenance',
            )
            .toList();
        _selected = _equipment.isEmpty ? null : _equipment.first;
        _loading = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _loading = false);
        _showMessage(context, error.toString());
      }
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _borrowerId.dispose();
    _purpose.dispose();
    _quantity.dispose();
    super.dispose();
  }

  Future<void> _pickDueDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _dueDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (date != null) setState(() => _dueDate = date);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final equipment = _selected;
    if (equipment == null) {
      _showMessage(context, 'There is no available equipment to issue.');
      return;
    }
    setState(() => _saving = true);
    try {
      await _repository.issueEquipment(
        equipment: equipment,
        borrowerName: _name.text,
        borrowerId: _borrowerId.text,
        borrowerType: _borrowerType,
        quantity: int.parse(_quantity.text),
        expectedReturn: _dueDate,
        purpose: _purpose.text,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        _showMessage(context, error.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: _loading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: ListView(
                shrinkWrap: true,
                children: [
                  Text(
                    'Issue equipment',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 16),
                  if (_equipment.isEmpty)
                    const Text('No equipment is available to issue.')
                  else
                    DropdownButtonFormField<Equipment>(
                      value: _selected,
                      decoration: const InputDecoration(labelText: 'Equipment'),
                      items: _equipment
                          .map(
                            (item) => DropdownMenuItem(
                              value: item,
                              child: Text(
                                '${item.name} (${item.availableQuantity} available)',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (value) => setState(() => _selected = value),
                    ),
                  _textField(_name, 'Borrower name', required: true),
                  _textField(_borrowerId, 'Borrower ID', required: true),
                  DropdownButtonFormField<String>(
                    value: _borrowerType,
                    decoration: const InputDecoration(
                      labelText: 'Borrower type',
                    ),
                    items: const ['Student', 'Teacher', 'Staff']
                        .map(
                          (value) => DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          ),
                        )
                        .toList(),
                    onChanged: (value) =>
                        setState(() => _borrowerType = value ?? 'Student'),
                  ),
                  _textField(
                    _quantity,
                    'Quantity',
                    required: true,
                    numeric: true,
                    integer: true,
                  ),
                  _textField(_purpose, 'Purpose / lab session'),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Expected return'),
                    subtitle: Text(DateFormat.yMMMd().format(_dueDate)),
                    trailing: const Icon(Icons.calendar_month),
                    onTap: _pickDueDate,
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: _saving || _equipment.isEmpty ? null : _save,
                    child: Text(_saving ? 'Saving...' : 'Confirm issue'),
                  ),
                ],
              ),
            ),
    );
  }
}

class MaintenanceScreen extends StatefulWidget {
  const MaintenanceScreen({required this.onChanged, super.key});

  final VoidCallback onChanged;

  @override
  State<MaintenanceScreen> createState() => _MaintenanceScreenState();
}

class _MaintenanceScreenState extends State<MaintenanceScreen> {
  final _repository = EquipmentRepository();
  List<Map<String, Object?>> _records = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final records = await _repository.getMaintenance();
      if (!mounted) return;
      setState(() {
        _records = records;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _add() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const MaintenanceForm(),
    );
    if (saved == true) {
      await _load();
      widget.onChanged();
    }
  }

  Future<void> _setStatus(int id, String status) async {
    try {
      await _repository.updateMaintenanceStatus(id, status);
      await _load();
      widget.onChanged();
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return Scaffold(
        body: _ErrorView(message: _error!, onRetry: _load),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Maintenance')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Schedule'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _records.isEmpty
            ? ListView(
                children: const [
                  SizedBox(height: 120),
                  Center(child: Text('No maintenance scheduled.')),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: _records.length,
                itemBuilder: (context, index) {
                  final row = _records[index];
                  final status = row['status'] as String;
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.build_outlined),
                      title: Text(
                        '${row['equipment_name']} • ${row['maintenance_type']}',
                      ),
                      subtitle: Text(
                        '${row['equipment_code']} • ${row['problem_description'] ?? 'No description'}\nDue ${_date(row['scheduled_date'] as String?)}',
                      ),
                      isThreeLine: true,
                      trailing: PopupMenuButton<String>(
                        tooltip: 'Update status',
                        onSelected: (value) =>
                            _setStatus(row['id'] as int, value),
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: 'In Progress',
                            child: Text('Start'),
                          ),
                          PopupMenuItem(
                            value: 'Completed',
                            child: Text('Complete'),
                          ),
                          PopupMenuItem(
                            value: 'Cancelled',
                            child: Text('Cancel'),
                          ),
                        ],
                        child: Chip(label: Text(status)),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class MaintenanceForm extends StatefulWidget {
  const MaintenanceForm({super.key});

  @override
  State<MaintenanceForm> createState() => _MaintenanceFormState();
}

class _MaintenanceFormState extends State<MaintenanceForm> {
  final _repository = EquipmentRepository();
  final _description = TextEditingController();
  List<Equipment> _equipment = [];
  Equipment? _selected;
  String _type = 'Routine';
  DateTime _date = DateTime.now();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final items = await _repository.getAll();
      if (mounted) {
        setState(() {
          _equipment = items;
          _selected = items.isEmpty ? null : items.first;
        });
      }
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    }
  }

  @override
  void dispose() {
    _description.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_selected == null) {
      _showMessage(context, 'Add equipment before scheduling maintenance.');
      return;
    }
    setState(() => _saving = true);
    try {
      await _repository.saveMaintenance(
        equipment: _selected!,
        type: _type,
        description: _description.text,
        scheduledDate: _date,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        _showMessage(context, error.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          Text(
            'Schedule maintenance',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          if (_equipment.isEmpty)
            const Text('Add equipment first.')
          else
            DropdownButtonFormField<Equipment>(
              value: _selected,
              decoration: const InputDecoration(labelText: 'Equipment'),
              items: _equipment
                  .map(
                    (item) =>
                        DropdownMenuItem(value: item, child: Text(item.name)),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _selected = value),
            ),
          DropdownButtonFormField<String>(
            value: _type,
            decoration: const InputDecoration(labelText: 'Type'),
            items: const ['Routine', 'Repair', 'Inspection', 'Calibration']
                .map(
                  (value) => DropdownMenuItem(value: value, child: Text(value)),
                )
                .toList(),
            onChanged: (value) => setState(() => _type = value ?? 'Routine'),
          ),
          TextField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'Problem / work description',
            ),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Scheduled date'),
            subtitle: Text(DateFormat.yMMMd().format(_date)),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2000),
                lastDate: DateTime.now().add(const Duration(days: 3650)),
              );
              if (picked != null) setState(() => _date = picked);
            },
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: Text(_saving ? 'Saving...' : 'Save schedule'),
          ),
        ],
      ),
    );
  }
}

class DamageReportsScreen extends StatefulWidget {
  const DamageReportsScreen({required this.onChanged, super.key});

  final VoidCallback onChanged;

  @override
  State<DamageReportsScreen> createState() => _DamageReportsScreenState();
}

class _DamageReportsScreenState extends State<DamageReportsScreen> {
  final _repository = EquipmentRepository();
  List<Map<String, Object?>> _records = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final records = await _repository.getDamageReports();
      if (!mounted) return;
      setState(() {
        _records = records;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  Future<void> _add() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const DamageReportForm(),
    );
    if (saved == true) {
      await _load();
      widget.onChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return Scaffold(
        body: _ErrorView(message: _error!, onRetry: _load),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Damage reports')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Report damage'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _records.isEmpty
            ? ListView(
                children: const [
                  SizedBox(height: 120),
                  Center(child: Text('No damage reports.')),
                ],
              )
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: _records.length,
                itemBuilder: (context, index) {
                  final row = _records[index];
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        Icons.report_problem_outlined,
                        color: row['severity'] == 'Critical'
                            ? Colors.red
                            : Colors.orange,
                      ),
                      title: Text(
                        '${row['equipment_name']} • ${row['severity']}',
                      ),
                      subtitle: Text(
                        '${row['report_id']} • ${row['status']}\n${row['description'] ?? ''}',
                      ),
                      isThreeLine: true,
                    ),
                  );
                },
              ),
      ),
    );
  }
}

class DamageReportForm extends StatefulWidget {
  const DamageReportForm({super.key});

  @override
  State<DamageReportForm> createState() => _DamageReportFormState();
}

class _DamageReportFormState extends State<DamageReportForm> {
  final _repository = EquipmentRepository();
  final _description = TextEditingController();
  final _reportedBy = TextEditingController();
  List<Equipment> _equipment = [];
  Equipment? _selected;
  String _severity = 'Minor';
  bool _repairRequired = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final rows = await _repository.getAll();
      if (mounted) {
        setState(() {
          _equipment = rows;
          _selected = rows.isEmpty ? null : rows.first;
        });
      }
    } catch (error) {
      if (mounted) _showMessage(context, error.toString());
    }
  }

  @override
  void dispose() {
    _description.dispose();
    _reportedBy.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_selected == null || _description.text.trim().isEmpty) {
      _showMessage(context, 'Choose equipment and describe the damage.');
      return;
    }
    setState(() => _saving = true);
    try {
      await _repository.createDamageReport(
        equipment: _selected!,
        severity: _severity,
        description: _description.text,
        reportedBy: _reportedBy.text,
        repairRequired: _repairRequired,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        _showMessage(context, error.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        16 + MediaQuery.viewInsetsOf(context).bottom,
      ),
      child: ListView(
        shrinkWrap: true,
        children: [
          Text('Report damage', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          if (_equipment.isEmpty)
            const Text('Add equipment first.')
          else
            DropdownButtonFormField<Equipment>(
              value: _selected,
              decoration: const InputDecoration(labelText: 'Equipment'),
              items: _equipment
                  .map(
                    (item) =>
                        DropdownMenuItem(value: item, child: Text(item.name)),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _selected = value),
            ),
          DropdownButtonFormField<String>(
            value: _severity,
            decoration: const InputDecoration(labelText: 'Severity'),
            items: const ['Minor', 'Moderate', 'Critical']
                .map(
                  (value) => DropdownMenuItem(value: value, child: Text(value)),
                )
                .toList(),
            onChanged: (value) => setState(() => _severity = value ?? 'Minor'),
          ),
          TextField(
            controller: _reportedBy,
            decoration: const InputDecoration(labelText: 'Reported by'),
          ),
          TextField(
            controller: _description,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'Damage description'),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Repair required'),
            value: _repairRequired,
            onChanged: (value) => setState(() => _repairRequired = value),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: Text(_saving ? 'Saving...' : 'Save report'),
          ),
        ],
      ),
    );
  }
}

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final _repository = EquipmentRepository();
  Map<String, int>? _summary;
  List<Map<String, Object?>> _activities = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final summary = await _repository.getDashboardSummary();
      final activities = await _repository.getActivities();
      if (!mounted) return;
      setState(() {
        _summary = summary;
        _activities = activities;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) return _ErrorView(message: _error!, onRetry: _load);
    final summary = _summary!;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Inventory summary',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          for (final entry in summary.entries)
            Card(
              child: ListTile(
                leading: const Icon(Icons.analytics_outlined),
                title: Text(_label(entry.key)),
                trailing: Text(
                  '${entry.value}',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
            ),
          const SizedBox(height: 16),
          Text(
            'Recent activity',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          if (_activities.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No activity recorded yet.'),
            )
          else
            ..._activities.map(
              (row) => Card(
                child: ListTile(
                  leading: const Icon(Icons.history),
                  title: Text('${row['message']}'),
                  subtitle: Text(
                    '${row['action']} • ${_date(row['created_at'] as String?)}',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({required this.user, super.key});

  final User user;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _newPin = TextEditingController();
  final _confirmPin = TextEditingController();
  bool _saving = false;

  @override
  void dispose() {
    _newPin.dispose();
    _confirmPin.dispose();
    super.dispose();
  }

  Future<void> _changePin() async {
    if (_newPin.text != _confirmPin.text) {
      _showMessage(context, 'PIN entries do not match.');
      return;
    }
    setState(() => _saving = true);
    try {
      await EquipmentRepository().changePin(widget.user.id, _newPin.text);
      if (!mounted) return;
      _newPin.clear();
      _confirmPin.clear();
      setState(() => _saving = false);
      _showMessage(context, 'PIN changed successfully.');
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      _showMessage(context, error.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.person_outline),
              title: Text(widget.user.name),
              subtitle: Text('${widget.user.username} • ${widget.user.role}'),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Change local PIN',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          TextField(
            controller: _newPin,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'New PIN (4–12 digits)',
            ),
          ),
          TextField(
            controller: _confirmPin,
            obscureText: true,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Confirm new PIN'),
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _saving ? null : _changePin,
            child: Text(_saving ? 'Saving...' : 'Change PIN'),
          ),
          const SizedBox(height: 20),
          const ListTile(
            leading: Icon(Icons.offline_bolt_outlined),
            title: Text('Offline storage'),
            subtitle: Text(
              'Equipment and activity are stored locally on this device.',
            ),
          ),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text(AppConstants.appName),
            subtitle: Text('Laboratory Equipment Management'),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.title,
    required this.value,
    required this.color,
  });

  final String title;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.labelMedium?.copyWith(color: Colors.black54),
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, color: Colors.red, size: 40),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }
}

TextFormField _textField(
  TextEditingController controller,
  String label, {
  bool required = false,
  bool numeric = false,
  bool integer = false,
  int maxLines = 1,
}) {
  return TextFormField(
    controller: controller,
    maxLines: maxLines,
    keyboardType: numeric
        ? TextInputType.numberWithOptions(decimal: !integer)
        : TextInputType.text,
    decoration: InputDecoration(labelText: label),
    validator: (value) {
      final text = value?.trim() ?? '';
      if (required && text.isEmpty) return '$label is required.';
      if (integer && text.isNotEmpty && int.tryParse(text) == null) {
        return '$label must be a whole number.';
      }
      if (numeric && text.isNotEmpty && double.tryParse(text) == null) {
        return 'Enter a valid number.';
      }
      return null;
    },
  );
}

String? _blankToNull(String value) {
  final trimmed = value.trim();
  return trimmed.isEmpty ? null : trimmed;
}

String _date(String? value) {
  if (value == null || value.isEmpty) return 'Not set';
  final parsed = DateTime.tryParse(value);
  return parsed == null ? value : DateFormat.yMMMd().format(parsed);
}

String _label(String key) {
  switch (key) {
    case 'total_units':
      return 'Total units';
    case 'available_units':
      return 'Available units';
    case 'issued_units':
      return 'Issued units';
    case 'damaged_units':
      return 'Damaged units';
    case 'maintenance_units':
      return 'Under maintenance';
    default:
      return key;
  }
}

void _showMessage(BuildContext context, String message) {
  final cleanMessage = message
      .replaceFirst('Bad state: ', '')
      .replaceFirst('Invalid argument(s): ', '');
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(cleanMessage)));
}
